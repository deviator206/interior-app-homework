'use strict';
angular.module('salesApp.date', [
  'salesApp.date.date-directive'
])
