'use strict';
angular.module('salesApp.customerSelection', [
  'salesApp.customerSelection.customer-selection-directive'
])
