New READ ME added!


Technician flow
> User Technician has following capability
	>search for status for any items from past / current based on criteria
		How a user can search ?
		User can search based on  ServiceId,SerialNumber,CustomerPhone,CustomerName,ProductName,TechnicianStartDate


		